<?php
define('BASE_PATH', realpath(__DIR__));

chdir(BASE_PATH);
